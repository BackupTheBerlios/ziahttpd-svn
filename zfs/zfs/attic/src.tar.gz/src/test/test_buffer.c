/*
** test_buffer.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 19:33:14 2006 
** Last update Sat Feb  4 22:28:29 2006 
*/



#include "/usr/pkg/include/dmalloc.h"
#include <buffer.h>


int main(int ac, char** av)
{
  buffer_t buf;
  int n;

  buffer_reset(&buf);
  buffer_push_front(&buf, (unsigned char*)"tttttttttt0", 11);

  for (n = 0; n < 11; ++n)
    {
      buffer_pop_front(&buf, 1);
      buffer_pop_back(&buf, 1);
    }
  buffer_release(&buf);

  return 0;
}
