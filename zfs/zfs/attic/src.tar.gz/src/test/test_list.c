/*
** test_list.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 22:28:55 2006 
** Last update Sat Feb  4 22:38:04 2006 
*/


#include <stdio.h>
#include <string.h>
#include "/usr/pkg/include/dmalloc.h"
#include <list.h>


int main(int ac, char** av)
{
  int n;
  list_t* list;
  list_t* lkp;

  list = list_init();

  for (n = 0; n < ac; ++n)
    {
      list_push_front(&list, (void*)av[n]);
/*       list_push_back(&list, (void*)av[n]); */
    }
  for (n = 0; n < ac; ++n)
    {
      lkp = list_lkp(list, (int(*)(void*, void*))strcmp, av[n]);
      if (lkp == 0)
	printf("cannot find the node...\n");
      else
	list_remove(&list, lkp, 0);
    }

  list_release(&list, 0);

  return 0;
}

