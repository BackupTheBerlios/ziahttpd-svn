/*
** ioev_callbacks.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 15:49:33 2006 
** Last update Sat Feb 11 16:47:39 2006 
*/


#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <ioev.h>


int	ioev_cb_accept_read(ioev_desc_t* evdesc)
{
  /* Return the number of
     connections accepted.
     Should not return 0 in this
     routine, else the accepting
     socket would be closed.
   */

  unsigned char optval;
  int nr_pending;
  int fd_conn;
  int n;

  /* Guess the pending connection count */
  nr_pending = 10;
  if (evdesc->on_read.size > 0)
    nr_pending = evdesc->on_read.size;

  /* Accept nr_pending connection */
  n = 0;
  while (n < nr_pending)
    {
      errno = 0;
      fd_conn = accept(evdesc->id, 0, 0);

      /* Set socket options */
      fcntl(fd_conn, F_SETFL, O_NONBLOCK);
      optval = 1;
      setsockopt(fd_conn, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(unsigned char));
      setsockopt(fd_conn, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(unsigned char));

      if (fd_conn < 0)
	{
	  switch (errno)
	    {
	    case ECONNABORTED:
	      --n;
	      break;
	    case EAGAIN:
	    default:
	      return 1;
	      break;
	    }
	}
      else
	{
	  /* add a new connection to the set */
	  ioev_add_event(evdesc->core, fd_conn,
			 ioev_cb_read,
			 ioev_cb_write,
			 ioev_cb_close,
			 evdesc->on_read.udata);
	}
      ++n;
    }

  return 1;
}


int	ioev_cb_accept_write(ioev_desc_t* evdesc)
{
  return 1;
}


int	ioev_cb_read(ioev_desc_t* evdesc)
{
  unsigned char* tmp;
  int nbytes;

  nbytes = 0;
  tmp = malloc(evdesc->on_read.size);
  if (tmp)
    {
      /* buffer_release(&evdesc->on_read.buf); */
      nbytes = read(evdesc->id, tmp, evdesc->on_read.size);
      if (nbytes <= 0)
	goto end_of_read;
      buffer_push_back(&evdesc->on_read.buf, tmp, nbytes);
    }

 end_of_read:
  if (tmp)
    free(tmp);
  return nbytes;
}


int	ioev_cb_write(ioev_desc_t* evdesc)
{
  int nbytes;
  int ntot;

  ntot = 0;
  while (evdesc->on_write.buf.nbytes > 0)
    {
      nbytes = write(evdesc->id, evdesc->on_write.buf.pdata, evdesc->on_write.buf.nbytes);
      if (nbytes <= 0)
	return nbytes;
      ntot += nbytes;
      buffer_pop_front(&evdesc->on_write.buf, nbytes);
    }
  return ntot;
}


int	ioev_cb_close(ioev_desc_t* evdesc)
{
  int nret;

  nret = ioev_remove_event(evdesc->core, evdesc->id);
  if (nret == -1)
    return -1;
  shutdown(evdesc->id, SHUT_RDWR);
  close(evdesc->id);
  return nret;
}
