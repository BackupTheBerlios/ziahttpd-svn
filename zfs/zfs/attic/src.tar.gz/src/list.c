/*
** list.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 13:35:04 2006 
** Last update Sat Feb  4 18:42:18 2006 
*/


#include <stdlib.h>
#include <list.h>



/* Doubly linked list
 */


/* Internal */

static void __attribute__((unused)) link_node_after(list_t** head, list_t* node)
{
  if (!*head)
    {
      *head = node;
    }
  else
    {
      node->prev = *head;
      if ((*head)->next)
	{
	  node->next = (*head)->next;
	  (*head)->next->prev = node;
	}
      (*head)->next = node;
    }
}

static void link_node_before(list_t** head, list_t* node)
{
  if (!*head)
    {
      *head = node;
    }
  else
    {
      node->next = *head;
      if ((*head)->prev)
	{
	  node->prev = (*head)->prev;
	  (*head)->prev->next = node;
	}
      (*head)->prev = node;
    }
}

static void unlink_node(list_t** head, list_t* node)
{
  if (*head == node)
    {
      *head = node->next;
      if (node->next)
	{
	  (*head)->prev = 0;
	  node->next->prev = 0;
	}
    }
  else
    {
      if (node->next)
	node->next->prev = node->prev;
      node->prev->next = node->next;
    }
}

static list_t* create_list(void* data)
{
  list_t* list;

  list = (list_t*)malloc(sizeof(list_t));
  if (list)
    {
      list->next = 0;
      list->prev = 0;
      list->data = data;
    }
  return list;
}


/* Exported */

list_t* list_init(void)
{
  return 0;
}

void list_release(list_t** list, void (*relfn)(void*))
{
  list_t* cur;
  list_t* sav;

  cur = *list;
  while (cur)
    {
      sav = cur;
      cur = cur->next;
      if (relfn)
	relfn(sav->data);
      free(sav);
    }
  *list = 0;
}

void list_foreach(list_t* list, void (*applyfn)(void*, void*), void* aux)
{
  while (list)
    {
      applyfn(list->data, aux);
      list = list->next;
    }
}

list_t* list_lkp(list_t* list, int (*cmpfn)(void*, void*), void* data)
{
  while (list)
    {
      if (cmpfn(list->data, data) == 0)
	return list;
      list = list->next;
    }
  return 0;
}

int list_push_front(list_t** list, void* aux)
{
  list_t* node;

  node = create_list(aux);
  if (node)
    {
      link_node_before(list, node);
      *list = node;
      return 0;
    }
  return -1;
}

int list_push_back(list_t** list, void* aux)
{
  list_t* node;
  list_t* ptr;

  node = create_list(aux);
  if (node == 0)
    return -1;

  if (*list == 0)
    {
      *list = node;
    }
  else
    {
      for (ptr = *list; ptr->next; ptr = ptr->next)
	;
      node->prev = ptr;
      ptr->next = node;
    }

  return 0;
}

void list_remove(list_t** head, list_t* node, void (*relfn)(void*))
{
  unlink_node(head, node);
  if (relfn)
    relfn(node->data);
  free(node);
}
