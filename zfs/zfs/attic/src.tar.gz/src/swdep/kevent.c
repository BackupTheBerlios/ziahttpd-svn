/*
** kevent.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 13:33:59 2006 
** Last update Sat Feb 11 16:27:47 2006 
*/


#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <ioev.h>
#include <list.h>


int	ioev_swdep_init(ioev_core_t* core)
{
  core->swdeps.kq = kqueue();
  return 0;
}

int	ioev_swdep_reset(ioev_core_t* core)
{
  core->swdeps.kq = -1;
  return 0;
}

int	ioev_swdep_release(ioev_core_t* core)
{
  close(core->swdeps.kq);
  return 0;
}


int	ioev_swdep_dispatch(ioev_core_t* core)
{
  list_t* list;
  ioev_desc_t* desc;
  unsigned char done;
  unsigned char closeme;
  unsigned char pending;
  int nelem;
  int n_to_delete;
  int nret;
  int n;

  /* kevent related data */
  struct kevent* kevlist;
  struct kevent* kev_to_delete;
  struct kevent* kevcurr;


  /* First process the list to
     know if there are data not
     read in buffers.
   */

  list = core->evlist;
  while (list)
    {
      desc = (ioev_desc_t*)list->data;
      if (desc->on_read.buf.nbytes > 0)
	return 0;
      list = list->next;
    }

  /* Alloc the list
   */
  nelem = core->ndesc;
  kevlist = malloc(nelem * sizeof(struct kevent));
  if (kevlist == 0)
    return -1;
  memset(kevlist, 0, nelem * sizeof(struct kevent));

  /* Put events of interest in set
   */
  done = 0;
  nelem = 0;
  n_to_delete = 0;
  list = core->evlist;
  while (list && done == 0)
    {
      pending = 0;
      desc = (ioev_desc_t*)list->data;
      kevcurr = &kevlist[nelem];

      /* This flag should always be set */
      if (desc->on_read.pending)
	{
	  /* a read operation is pending */
	  EV_SET(kevcurr, desc->id, EVFILT_READ, EV_ADD, 0, 0, (uintptr_t)desc);
	  pending = 1;
	}
      /* else if (desc->on_write.pending) */
      if (desc->on_write.buf.nbytes)
	{
	  /* a write operation is pending */
	  EV_SET(kevcurr, desc->id, EVFILT_WRITE, EV_ADD, 0, 0, (uintptr_t)desc);
	  printf(">>>>adding forwritting \n");
	  pending = 1;
	  ++n_to_delete;
	}
      if (pending == 1)
	++nelem;
      list = list->next;
    }

  /* Alloc the to delete list
   */
  kev_to_delete = malloc(nelem * sizeof(struct kevent));
  if (kev_to_delete == 0)
    return -1;
  memset(kev_to_delete, 0, nelem * sizeof(struct kevent));

  /* Get events of interest
   */
  do
    {
      errno = 0;
      nelem = kevent(core->swdeps.kq, kevlist, nelem, kevlist, core->ndesc, 0);
    }
  while (nelem == -1 && errno == EINTR);
  if (nelem == -1)
    return -1;

  /* Process events of interest
   */
  n_to_delete = 0;
  for (n = 0; n < nelem; ++n)
    {
      closeme = 0;
      kevcurr = &kevlist[n];
      desc = (ioev_desc_t*)kevcurr->udata;

      /* End of file detected */
      if (kevcurr->flags & EV_EOF)
	closeme = 1;

      /* Error, try to guess socket closing */
      if (kevcurr->flags & EV_ERROR)
	{
	  switch (kevcurr->data)
	    {
	    case ENOTCONN:
	    case EAGAIN:
	    case ENOENT:
	    case EBADF:
	      break;
	    default:
	      closeme = 1;
	      break;
	    }
	}

      /* Process the pending operation */
      if ((kevcurr->filter == EVFILT_READ) && closeme == 0)
	{
	  nret = 0;
	  desc->on_read.size = (int)kevcurr->data;
	  if (desc->on_read.iocb_fn)
	    nret = desc->on_read.iocb_fn(desc);
	  if (nret <= 0)
	    closeme = 1;
	}
      if ((kevcurr->filter == EVFILT_WRITE) && closeme == 0)
	{
	  nret = 0;
	  desc->on_write.size = (int)kevcurr->data;
	  if (desc->on_write.iocb_fn)
	    nret = desc->on_write.iocb_fn(desc);

	  /* Set element for deletion */
	  EV_SET(&kev_to_delete[n_to_delete], desc->id, EVFILT_WRITE, EV_DELETE, 0, 0, 0);
	  ++n_to_delete;

	  if (nret <= 0)
	    closeme = 1;
	}

      /* If the socket has to be closed */
      if (closeme == 1)
	{
	  if (desc->on_close.iocb_fn)
	    nret = desc->on_close.iocb_fn(desc);
	}
    }

  /* delete element mark for writing
   */
  do
    {
      errno = 0;
      nelem = kevent(core->swdeps.kq, kev_to_delete, n_to_delete, 0, 0, 0);
    }
  while (nelem == -1 && errno == EINTR);

  free(kev_to_delete);
  free(kevlist);
  return 0;
}
