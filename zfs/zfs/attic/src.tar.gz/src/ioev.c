/*
** ioev.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 15:25:56 2006 
** Last update Sun Feb  5 14:16:08 2006 
*/


#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <buffer.h>
#include <ioev.h>
#include <list.h>


/* todos 
   . remove event from the list
   . code a makefile to build a lib according to the good host configuration
   . code the buffers(use efence + debugging tools to track leaks)
   . code the list(use efence + debugging tools to track leaks)
   . code echo server
   . clean debug for the library
 */


/* Todos
   + call swdep part
 */



/* ideas
   . every time an io operation is performed,
   the list should be reordered so that pending
   operations come first.
   . non portable part includes the dispatcher
   and 
   . statically allocate the kevent list
   . avoid casting data to fit into another interface
   -> this is bad for performances, and bad for code
   maintenance.
   So swdep part should handle the adding/removale
   of io operations.
   Test the performances for that point
   Too, letting the swdep part handle such operation
   let possible the use of aio.
   The probleme is to store data related with an
   event.
   The kqueue interface allow it by the udata in the
   kevent structure.
 */


/* int	ioev_add_descriptor(ioev_core_t*, ioev_descid_t) */
/* { */
/* } */

/* int	ioev_remove_descriptor(ioev_core_t*, ioev_descid_t) */
/* { */
/* } */

/* int	ioev_find_descriptor_byid(ioev_core_t*, ioev_descid_t) */
/* { */
/* } */

/* int	ioev_dispatch(ioev_core_t* core) */
/* { */
/* } */


/* Internal
 */

static inline void reset_desc(ioev_desc_t* desc)
{
  memset(desc, 0, sizeof(ioev_desc_t));
  desc->id = -1;
  buffer_reset(&desc->on_read.buf);
  buffer_reset(&desc->on_write.buf);
  buffer_reset(&desc->on_close.buf);
}

static ioev_desc_t* alloc_desc(void)
{
  ioev_desc_t* desc;

  desc = malloc(sizeof(ioev_desc_t));
  if (desc)
    reset_desc(desc);
  return desc;
}

static void release_desc(ioev_desc_t* desc)
{
  /* release the buffer here?
     not if owned by the user.
   */
  buffer_release(&desc->on_read.buf);
  buffer_release(&desc->on_write.buf);
  buffer_release(&desc->on_close.buf);
  free(desc);
}

static inline void reset_core(ioev_core_t* core)
{
  /* release the list */
  /* call the swdep part */
  core->ndesc = 0;
  ioev_swdep_reset(core);
}


/* Exported
 */

int	ioev_alloc_core(ioev_core_t** core)
{
  ioev_core_t* iocore;
  int nret;
  
  nret = 0;
  *core = 0;

  /* allocation */
  iocore = malloc(sizeof(ioev_core_t));
  if (iocore == 0)
    {
      nret = -1;
      goto ret_from_alloc;
    }
  
  /* init */
  reset_core(iocore);
  ioev_swdep_init(iocore);
  *core = iocore;

 ret_from_alloc:
  /* an error occured */
  if (nret != 0)
    {
      if (iocore)
	ioev_release_core(iocore);
    }

  return nret;
}


int	ioev_release_core(ioev_core_t* core)
{
  ioev_swdep_release(core);
  list_release(&core->evlist, (void(*)(void*))release_desc);
  free(core);
  return 0;
}


int	ioev_add_event(ioev_core_t* core,
		       ioev_descid_t id,
		       int (*onread)(ioev_desc_t*),
		       int (*onwrite)(ioev_desc_t*),
		       int (*onclose)(ioev_desc_t*),
		       void* udata)
{
  ioev_desc_t* desc;

  /* Create a new descriptor */
  desc = alloc_desc();
  if (desc == 0)
    return -1;
  reset_desc(desc);
  desc->core = core;
  desc->id = id;
  desc->on_read.iocb_fn = onread;
  desc->on_read.udata = udata;
  desc->on_write.iocb_fn = onwrite;
  desc->on_write.udata = udata;
  desc->on_close.iocb_fn = onclose;
  desc->on_close.udata = udata;

  /* Add it to the list push back the
     event, since the front of the list
     is reserved for pending io.
   */
  desc->on_read.pending = 1;
  ++core->ndesc;
  list_push_back(&core->evlist, (void*)desc);

  return 0;
}


static int cmp_bydesc(ioev_desc_t* evdesc, void* id)
{
  return !(evdesc->id == (unsigned long)id);
}

int	ioev_remove_event(ioev_core_t* core, ioev_descid_t id)
{
  list_t* node;

  node = list_lkp(core->evlist, (int (*)(void*, void*))cmp_bydesc, (void*)id);
  if (node == 0)
    return -1;

  list_remove(&core->evlist, node, (void(*)(void*))release_desc);
  --core->ndesc;
  return 0;
}


int	ioev_dispatch(ioev_core_t* core)
{
  return ioev_swdep_dispatch(core);
}


int	ioev_read(ioev_core_t* core, ioev_desc_t* desc, unsigned char* buf, int nbytes)
{
  if (desc->on_read.buf.nbytes < nbytes)
    nbytes = desc->on_read.buf.nbytes;
  if (nbytes == 0)
    return 0;

  /* Read nbytes from the front of buffer */
  memcpy(buf, desc->on_read.buf.pdata, nbytes);
  buffer_pop_front(&desc->on_read.buf, nbytes);
  
  desc->on_read.pending = 1;
  return nbytes;
}


int	ioev_write(ioev_core_t* core, ioev_desc_t* desc, unsigned char* buf, int nbytes)
{
  buffer_push_back(&desc->on_write.buf, buf, nbytes);
  desc->on_write.pending = 1;
  return nbytes;
}


int	ioev_close(ioev_core_t* core, ioev_desc_t* desc)
{
  desc->on_close.pending = 1;
  return 0;
}
