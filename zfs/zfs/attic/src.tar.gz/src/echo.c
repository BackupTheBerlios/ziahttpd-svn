/*
** echo.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 15:55:44 2006 
** Last update Sun Feb  5 14:42:03 2006 
*/


#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <buffer.h>
#include <list.h>
#include <ioev.h>
#include <echo.h>


void echo_init(echo_t* echo)
{
  echo->done = 0;
  ioev_alloc_core(&echo->iocore);
}


void echo_do(echo_t* echo)
{
  int fd_accept;
  struct sockaddr_in inaddr;
  unsigned char optval;
  list_t* list;
  ioev_desc_t* evdesc;
  unsigned char* tmp;
  int nbytes;

  /* Create a listening reusable socket */
  fd_accept = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (fd_accept == -1)
    {
      perror("accept_socket");
      return ;
    }
  memset(&inaddr, 0, sizeof(struct sockaddr));
  inaddr.sin_port = htons(40000);
  inaddr.sin_addr.s_addr = INADDR_ANY;
  inaddr.sin_family = PF_INET;
  if (bind(fd_accept, (struct sockaddr*)&inaddr, sizeof(struct sockaddr_in)) == -1)
    {
      perror("bind_socket");
      return ;
    }
  listen(fd_accept, 50);
  optval = 1;
  setsockopt(fd_accept, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &optval, sizeof(optval));
  fcntl(fd_accept, F_SETFL, O_NONBLOCK);

  /* register events to react to */
  ioev_add_event(echo->iocore, fd_accept, ioev_cb_accept_read, ioev_cb_accept_write, ioev_cb_close, (void*)echo);

  while (1)
    {
      /* dispatch events */
      ioev_dispatch(echo->iocore);

      /* Foreach data read, write the echo msg */
      for (list = echo->iocore->evlist; list; list = list->next)
	{
	  evdesc = (ioev_desc_t*)list->data;

	  /* There is something to read */
	  if (evdesc->on_read.buf.nbytes)
	    {
/* - 	      tmp = malloc(10); */
	      tmp = malloc(evdesc->on_read.buf.nbytes);
	      if (tmp)
		{
/* -		  nbytes = ioev_read(echo->iocore, evdesc, tmp, 10); */
		  nbytes = ioev_read(echo->iocore, evdesc, tmp, evdesc->on_read.buf.nbytes);
		  if (nbytes > 0)
		    ioev_write(echo->iocore, evdesc, tmp, nbytes);
		  free(tmp);
		}
	    }
	}
    }
}


void echo_release(echo_t* echo)
{
  ioev_release_core(echo->iocore);
}
