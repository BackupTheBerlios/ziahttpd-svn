/*
** main.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 10:51:55 2006 
** Last update Sun Feb  5 00:48:38 2006 
*/


#include <echo.h>


int main(int ac, char** av)
{
  echo_t echo;

  echo_init(&echo);
  echo_do(&echo);
  echo_release(&echo);

  return 0;
}
