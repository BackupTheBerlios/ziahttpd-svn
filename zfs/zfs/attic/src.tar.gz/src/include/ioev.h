/*
** ioev.h for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 13:38:45 2006 
** Last update Sun Feb  5 14:14:37 2006 
*/


#ifndef IOEV_H
# define IOEV_H


/* Software dependent part
 */


#ifdef IOEV_USE_KEVENT

#include <sys/event.h>
#include <sys/time.h>
#include <buffer.h>
#include <list.h>

/* typedef HANDLE ioev_descid_t */
typedef int ioev_descid_t;

typedef struct
{
  int kq;
} ioev_swdep_t;

#endif /* IOEV_USE_KEVENT */



/* Ioev generic part
 */

struct ioev_desc;
struct ioev_core;

typedef struct ioev_handler
{
  /* io callback */
  void* udata;
  int (*iocb_fn)(struct ioev_desc*);

  /* io data related */
  buffer_t buf;

  /* io operation is pending */
  unsigned char pending;

  /* remove on last operation */
  unsigned char persist;

  /* dependent part, hints */
  int size;

} ioev_handler_t;


typedef struct ioev_desc
{
  struct ioev_core* core;
  ioev_descid_t id;
  ioev_handler_t on_read;
  ioev_handler_t on_write;
  ioev_handler_t on_close;
} ioev_desc_t;


typedef struct ioev_core
{
  unsigned int ndesc;
  list_t* evlist;
  ioev_swdep_t swdeps;
} ioev_core_t;


/* Api
 */
int	ioev_alloc_core(ioev_core_t**);
int	ioev_reset_core(ioev_core_t*);
int	ioev_release_core(ioev_core_t*);
int	ioev_add_event(ioev_core_t*,
		       ioev_descid_t,
		       int (*)(ioev_desc_t*),
		       int (*)(ioev_desc_t*),
		       int (*)(ioev_desc_t*),
		       void*);
int	ioev_remove_event(ioev_core_t*, ioev_descid_t);
int	ioev_write(ioev_core_t*, ioev_desc_t*, unsigned char*, int);
int	ioev_read(ioev_core_t*, ioev_desc_t*, unsigned char*, int);
int	ioev_close(ioev_core_t*, ioev_desc_t*);
int	ioev_dispatch(ioev_core_t*);


/* Callbacks
 */
int	ioev_cb_accept_read(ioev_desc_t*);
int	ioev_cb_accept_write(ioev_desc_t*);
int	ioev_cb_read(ioev_desc_t* evdesc);
int	ioev_cb_write(ioev_desc_t* evdesc);
int	ioev_cb_close(ioev_desc_t* evdesc);


/* Swdep
 */
int	ioev_swdep_init(ioev_core_t*);
int	ioev_swdep_reset(ioev_core_t*);
int	ioev_swdep_release(ioev_core_t*);
int	ioev_swdep_read(ioev_core_t*, ioev_descid_t, buffer_t*);
int	ioev_swdep_write(ioev_core_t*, ioev_descid_t, buffer_t*);
int	ioev_swdep_close(ioev_core_t*, ioev_descid_t);
int	ioev_swdep_dispatch(ioev_core_t*);


#endif /* IOEV_H */
