/*
** buffer.h for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 15:33:24 2006 
** Last update Sat Feb  4 19:52:43 2006 
*/


#ifndef BUFFER_H
# define BUFFER_H


typedef struct
{
  int nbytes;
  unsigned char* pdata;
} buffer_t;


int buffer_reset(buffer_t*);
int buffer_release(buffer_t*);
int buffer_push_back(buffer_t*, unsigned char*, int);
int buffer_push_front(buffer_t*, unsigned char*, int);
int buffer_pop_back(buffer_t*, int);
int buffer_pop_front(buffer_t*, int);
void buffer_print(buffer_t*);


#endif /* ! BUFFER_H */
