/*
** list.h for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 15:34:23 2006 
** Last update Sat Feb  4 18:41:18 2006 
*/


#ifndef LIST_H
# define LIST_H


typedef struct list
{
  void* data;
  struct list* next;
  struct list* prev;
} list_t;


/* Api
 */
list_t*	list_init(void);
void	list_release(list_t** list, void (*relfn)(void*));
void	list_foreach(list_t* list, void (*applyfn)(void*, void*), void* aux);
list_t*	list_lkp(list_t* list, int (*cmpfn)(void*, void*), void* data);
int	list_push_front(list_t** list, void* aux);
int	list_push_back(list_t** list, void* aux);
void	list_remove(list_t** head, list_t* node, void (*relfn)(void*));


#endif /* ! LIST_H */
