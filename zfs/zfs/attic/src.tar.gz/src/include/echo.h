/*
** echo.h for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 15:55:50 2006 
** Last update Sun Feb  5 14:16:37 2006 
*/


#ifndef ECHO_H
# define ECHO_H


/* implement a simple echo server
 */


#include <ioev.h>


typedef struct
{
  unsigned char done;
  ioev_core_t* iocore;
} echo_t;


void echo_init(echo_t*);
void echo_do(echo_t*);
void echo_release(echo_t*);


#endif /* ! ECHO_H */
