/*
** buffer.c for  in /home/texane/texane/tmp/kevent/src
** 
** Made by 
** Login   <texane@epita.fr>
** 
** Started on  Sat Feb  4 13:35:13 2006 
** Last update Sat Feb  4 22:24:58 2006 
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <buffer.h>


/* internals
 */


/* exported
 */

int buffer_reset(buffer_t* buf)
{
  buf->nbytes = 0;
  buf->pdata = 0;
  return 0;
}


int buffer_release(buffer_t* buf)
{
  if (buf->pdata)
    free(buf->pdata);
  buffer_reset(buf);
  return 0;
}


int buffer_push_back(buffer_t* buf, unsigned char* data, int nbytes)
{
  unsigned char* wrk;

  if (nbytes == 0)
    return -1;

  /* get the new buffer */
  wrk = malloc((buf->nbytes + nbytes) * sizeof(char));
  if (wrk == 0)
    return -1;
  if (buf->pdata)
    memcpy(wrk, buf->pdata, buf->nbytes);
  memcpy(wrk + buf->nbytes, data, nbytes);

  /* affect the old one */
  nbytes += buf->nbytes;
  buffer_release(buf);
  buf->pdata = wrk;
  buf->nbytes = nbytes;
  return 0;
}


int buffer_push_front(buffer_t* buf, unsigned char* data, int nbytes)
{
  unsigned char* wrk;

  if (nbytes == 0)
    return -1;

  wrk = malloc((buf->nbytes + nbytes) * sizeof(char));
  if (wrk == 0)
    return -1;
  memcpy(wrk, data, nbytes);
  if (buf->pdata)
    memcpy(wrk + nbytes, buf->pdata, buf->nbytes);

  nbytes += buf->nbytes;
  buffer_release(buf);
  buf->pdata = wrk;
  buf->nbytes = nbytes;
  return 0;
}


int buffer_pop_front(buffer_t* buf, int nbytes)
{
  int i;
  int j;

  if (nbytes > buf->nbytes)
    nbytes = buf->nbytes;

  if (nbytes == 0)
    return -1;

  i = 0;
  j = nbytes;
  while (j < buf->nbytes)
    {
      buf->pdata[i] = buf->pdata[j];
      ++i;
      ++j;
    }

  buf->nbytes -= nbytes;
  return 0;
}

int buffer_pop_back(buffer_t* buf, int nbytes)
{
  if (nbytes > buf->nbytes)
    nbytes = buf->nbytes;

  if (nbytes == 0)
    return -1;

  /* remove nbytes from the back */
  buf->nbytes -= nbytes;
  return 0;
}

void buffer_print(buffer_t* buf)
{
  int n;

  printf("--> @0x%p, #%d\n", buf->pdata, buf->nbytes);
  if (buf->pdata == 0 || buf->nbytes == 0)
    {
      printf("buffer is empty\n");
      return ;
    }

  for (n = 0; n < buf->nbytes; ++n)
    {
      printf("%c", buf->pdata[n]);
      fflush(stdout);
    }
  printf("\n");
}
